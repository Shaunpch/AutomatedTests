///<reference types = "Cypress"/>

export const EndToEndTests = (Username, Password, client, Project,Hours,comment) => {

    describe('End To End Test - Flo360',function()
    {
        before(function()
        {
            cy.visit('/')
        })
        it('Testcase1', function()
        {
        })
    })
}
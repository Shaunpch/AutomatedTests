///<reference types = "Cypress"/>

import { PurchaseOrdersPageTests } from "../../../src/FLO360/Purchase Orders/PurchaseOrders";


PurchaseOrdersPageTests
(
    //name
    //'shaunm@pepkorit.com',
    //incorrectname
    //'shauntest@test.com',
    //password
    //'Slalas1234',
    //incorrectPassword
    //'Test',
    //DEVurl,QAurl,PRODurl
    'https://flo360.pchqas.com'
    //'http://qa.fica.pdws.co.za/user/index/login#close',
    //'http://prod.fica.pdws.co.za/user/index/login#close' 
); 
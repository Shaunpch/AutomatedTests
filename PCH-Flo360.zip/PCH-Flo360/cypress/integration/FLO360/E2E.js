///<reference types = "Cypress"/>

import { EndToEndTests } from "../../../cypress/src/FLO360/E2E";


EndToEndTests
(
    //Username
    'Shaun.Meyer',
    //Password
    'PCHsm@2020',
    //Client
    'NON CLIENT WORK (900)',
    //Project code
    'IT INTERNAL PROJECTS (PCH33769)',
    //Hours worked
    '8',
    //Comment
    'Regression testing and automation'

); 
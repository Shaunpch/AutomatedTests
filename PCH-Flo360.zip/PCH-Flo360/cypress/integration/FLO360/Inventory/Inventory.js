///<reference types = "Cypress"/>

import { InventoryPageTests } from "../../../src/FLO360/Inventory/Inventory";


InventoryPageTests
(
    //name
    //'shaunm@pepkorit.com',
    //incorrectname
    //'shauntest@test.com',
    //password
    //'Slalas1234',
    //incorrectPassword
    //'Test',
    //DEVurl,QAurl,PRODurl
    'https://flo360.pchqas.com'
    //'http://qa.fica.pdws.co.za/user/index/login#close',
    //'http://prod.fica.pdws.co.za/user/index/login#close' 
); 
///<reference types = "Cypress"/>

import { TeamsPageTests } from "../../../src/FLO360/Team/Team";


TeamsPageTests
(
    //name
    //'shaunm@pepkorit.com',
    //incorrectname
    //'shauntest@test.com',
    //password
    //'Slalas1234',
    //incorrectPassword
    //'Test',
    //DEVurl,QAurl,PRODurl
    'https://flo360.pchqas.com'
    //'http://qa.fica.pdws.co.za/user/index/login#close',
    //'http://prod.fica.pdws.co.za/user/index/login#close' 
); 
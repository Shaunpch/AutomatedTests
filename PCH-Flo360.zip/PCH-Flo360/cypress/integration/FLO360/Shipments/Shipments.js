///<reference types = "Cypress"/>

import { ShipmentsPageTests } from "../../../src/FLO360/Shipments/Shipments";


ShipmentsPageTests
(
    //name
    //'shaunm@pepkorit.com',
    //incorrectname
    //'shauntest@test.com',
    //password
    //'Slalas1234',
    //incorrectPassword
    //'Test',
    //DEVurl,QAurl,PRODurl
    'https://flo360.pchqas.com'
    //'http://qa.fica.pdws.co.za/user/index/login#close',
    //'http://prod.fica.pdws.co.za/user/index/login#close' 
); 